mvn spring-boot:run
